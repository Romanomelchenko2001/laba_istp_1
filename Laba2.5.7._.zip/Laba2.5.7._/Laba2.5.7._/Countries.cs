﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._
{
    public partial class Countries
    {
        public Countries()
        {
            Students = new HashSet<Students>();
            Universities_Collection = new HashSet<Universities>();
        }

        public int CountryId { get; set; }
        [Required (ErrorMessage ="This field cannot be empty, try again")]
        [Display (Name="Назва Країни")]
        public string CountryName { get; set; }

        public virtual ICollection<Students> Students { get; set; }
        public virtual ICollection<Universities> Universities_Collection { get; set; }
    }
}
