﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._
{
    public partial class Departments
    {
        public Departments()
        {
            Groups = new HashSet<Groups>();
        }
        [Required(ErrorMessage = "Поле не повинно бути порожнім")]
        [Display(Name = "Назва Департаменту")]
        public string DepartmentName { get; set; }
        public int DepartmentId { get; set; }
        [Display(Name = "Назва Факу")]
        public int DepartmentFacultyId { get; set; }
        [Display(Name = "Назва Факу")]
        public virtual Faculties DepartmentFaculty { get; set; }
        public virtual ICollection<Groups> Groups { get; set; }
    }
}
