﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Laba2._5._7._.Models; 

namespace Laba2._5._7._
{
    public partial class DbUniversityContext : DbContext
    {
        public DbUniversityContext()
        {
        }

        public DbUniversityContext(DbContextOptions<DbUniversityContext> options)
            : base(options)
        {
        }


        public virtual DbSet<Countries> Countries { get; set; }
        public virtual DbSet<Departments> Departments { get; set; }
        public virtual DbSet<Faculties> Faculties { get; set; }
        public virtual DbSet<Groups> Groups { get; set; }
        public virtual DbSet<Students> Students { get; set; }
        public virtual DbSet<Universities> Universities { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=DESKTOP-LSJPNOA\\SQLEXPRESS01; Database= DbUniversity; Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Countries>(entity =>
            {
                entity.HasKey(e => e.CountryId);

                entity.Property(e => e.CountryId).HasColumnName("Country_ID");

                entity.Property(e => e.CountryName)
                    .IsRequired()
                    .HasColumnName("Country_NAME")
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Departments>(entity =>
            {
                entity.HasKey(e => e.DepartmentId);

                entity.Property(e => e.DepartmentId).HasColumnName("Department_ID");

                entity.Property(e => e.DepartmentFacultyId).HasColumnName("Department_Faculty_ID");

                entity.Property(e => e.DepartmentName)
                    .IsRequired()
                    .HasColumnName("Department_NAME")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.HasOne(d => d.DepartmentFaculty)
                    .WithMany(p => p.Departments)
                    .HasForeignKey(d => d.DepartmentFacultyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Departments_Faculties");
            });

            modelBuilder.Entity<Faculties>(entity =>
            {
                entity.HasKey(e => e.FacultyId);

                entity.Property(e => e.FacultyId).HasColumnName("Faculty_ID");

                entity.Property(e => e.FacultyName)
                    .HasColumnName("Faculty_NAME")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.FacultyUniversityId).HasColumnName("Faculty_University_ID");

                entity.HasOne(d => d.FacultyUniversity)
                    .WithMany(p => p.Faculties)
                    .HasForeignKey(d => d.FacultyUniversityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Faculties_Universities");
            });

            modelBuilder.Entity<Groups>(entity =>
            {
                entity.HasKey(e => e.GroupId);

                entity.Property(e => e.GroupId).HasColumnName("Group_ID");

                entity.Property(e => e.GroupDepartmentId).HasColumnName("Group_Department_ID");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasColumnName("Group_NAME")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.HasOne(d => d.GroupDepartment)
                    .WithMany(p => p.Groups)
                    .HasForeignKey(d => d.GroupDepartmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Groups_Departments");
            });

            modelBuilder.Entity<Students>(entity =>
            {
                entity.HasKey(e => e.StudentId);

                entity.Property(e => e.StudentId).HasColumnName("Student_ID");

                entity.Property(e => e.StudentBirthDate).HasColumnName("Student_BirthDate");

                entity.Property(e => e.StudentCountryId).HasColumnName("Student_Country_ID");

                entity.Property(e => e.StudentCourseNum).HasColumnName("Student_Course_NUM");

                entity.Property(e => e.StudentGroupId).HasColumnName("Student_Group_ID");

                entity.Property(e => e.StudentName)
                    .IsRequired()
                    .HasColumnName("Student_NAME")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.HasOne(d => d.StudentCountry)
                    .WithMany(p => p.Students)
                    .HasForeignKey(d => d.StudentCountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Students_Countries");

                entity.HasOne(d => d.StudentGroup)
                    .WithMany(p => p.Students)
                    .HasForeignKey(d => d.StudentGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Students_Groups");
            });

            modelBuilder.Entity<Universities>(entity =>
            {
                entity.HasKey(e => e.UniversityId);

                entity.Property(e => e.UniversityId).HasColumnName("University_ID");

                entity.Property(e => e.UniversityCountryId).HasColumnName("University_Country_ID");

                entity.Property(e => e.UniversityName)
                    .IsRequired()
                    .HasColumnName("University_NAME")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.HasOne(d => d.UniversityCountry)
                    .WithMany(p => p.Universities_Collection)
                    .HasForeignKey(d => d.UniversityCountryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Universities_Countries");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
