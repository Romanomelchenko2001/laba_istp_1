﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._
{
    public partial class Groups
    {
        public Groups()
        {
            Students = new HashSet<Students>();
        }

        public int GroupId { get; set; }
        [Required(ErrorMessage = "Поле не повинно бути порожнім")]
        [Display(Name = "Назва Групи")]
        public string GroupName { get; set; }
        [Display(Name = "Назва Кафедри")]
        public int GroupDepartmentId { get; set; }
        [Display(Name = "Назва Кафедри")]
        public virtual Departments GroupDepartment { get; set; }
        public virtual ICollection<Students> Students { get; set; }
    }
}
