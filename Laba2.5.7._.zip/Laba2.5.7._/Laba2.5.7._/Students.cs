﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._
{
    public partial class Students
    {
        [Required(ErrorMessage = "Поле не повинно бути порожнім")]
        [Display(Name = "Ім'я студент")]
        public string StudentName { get; set; }
        public int StudentId { get; set; }
        public int StudentGroupId { get; set; }

        public int StudentCountryId { get; set; }
        [Required(ErrorMessage = "Поле не повинно бути порожнім")]
        [Display(Name = "Курс студент")]
        public int StudentCourseNum { get; set; }
        [Required(ErrorMessage = "Поле не повинно бути порожнім")]
        [Display(Name = "Рік народження")]
        public int StudentBirthDate { get; set; }
        [Display(Name = "Країна")]
        public virtual Countries StudentCountry { get; set; }
        [Display(Name = "Група")]
        public virtual Groups StudentGroup { get; set; }
    }
}
