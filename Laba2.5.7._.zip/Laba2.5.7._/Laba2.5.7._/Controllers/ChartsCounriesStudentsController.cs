﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Laba2._5._7._.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChartsCounriesStudentsController : ControllerBase
    {
        private readonly DbUniversityContext _context;

        public ChartsCounriesStudentsController(DbUniversityContext dbUniversityContext)
        {
            _context = dbUniversityContext;
        }
        [HttpGet("JsonData")]
        public JsonResult JsonData()
        {
            var Countries = _context.Countries.Include(vtcr => vtcr.Students).ToList();

            List<object> CountryStudent = new List<object>();

            CountryStudent.Add(new[] {"Країна","Ксть студентів" });
            foreach (var C in Countries)
            {
                CountryStudent.Add(new object[] {C.CountryName, C.Students.Count()});
            }

            return new JsonResult(CountryStudent);
        }
    }
}