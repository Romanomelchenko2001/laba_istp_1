﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._;

namespace Laba2._5._7._.Controllers
{
    public class StudentsController : Controller
    {
        private readonly DbUniversityContext _context;
        private int _min_student_birthdate = 1900;
        private int _max_student_birthdate = 2015;
        private int maxcourse = 6;
        private string forbidden_symbols = "1234567890!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        public StudentsController(DbUniversityContext context)
        {
            _context = context;
        }

        // GET: Students
        public async Task<IActionResult> Index(int?id)
        {
            if (id == null)
            {
                return RedirectToAction("Index", "Countries");
            }
            ViewBag.GroupsId = Convert.ToInt32(id);
            ViewBag.GroupsName = _context.Groups.Where(c => c.GroupId == Convert.ToInt32(id)).FirstOrDefault().GroupName;
            int DepId = _context.Groups.Where(c => c.GroupId == Convert.ToInt32(id)).FirstOrDefault().GroupDepartmentId;
            int Fa = _context.Departments.Where(c => c.DepartmentId == DepId).FirstOrDefault().DepartmentFacultyId;
            int UniversityId = _context.Faculties.Where(c => c.FacultyId == Fa).FirstOrDefault().FacultyUniversityId;
            var r = _context.Universities.Where(c => c.UniversityId == UniversityId).FirstOrDefault().UniversityCountryId;
            ViewBag.CountryId = r;
            var StudentsInGroups = _context.Students.Where(cr => cr.StudentGroupId == id).Include(c => c.StudentGroup);
            return View(await StudentsInGroups.ToListAsync());
        }

        // GET: Students/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var students = await _context.Students
                .Include(s => s.StudentCountry)
                .Include(s => s.StudentGroup)
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (students == null)
            {
                return NotFound();
            }

            return RedirectToAction(nameof(Index),"Countries");
        }

        // GET: Students/Create
        public IActionResult Create(int?id, int?CountryId)
        {
            ViewBag.GrouptId = id;
            ViewBag.GroupName = _context.Groups.Where(cr => cr.GroupId == Convert.ToInt32(id)).FirstOrDefault().GroupName;
            ViewBag.CountryId = _context.Countries.Where(cr => cr.CountryId == Convert.ToInt32(CountryId)).FirstOrDefault().CountryId;
            return View();
        }

        // POST: Students/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int id, int CountryId,[Bind("StudentName,StudentId,StudentGroupId,StudentCountryId,StudentCourseNum,StudentBirthDate")] Students students)
        {

            students.StudentCountryId = CountryId;
            students.StudentGroupId = id;
            //students.StudentCountry = _context.Countries.Where(c => c.CountryId == CountryId).FirstOrDefault();
            if (ModelState.IsValid)
            {
                //Перевірка на неприпустимі символи в імені студента
                for (int i = 0; i < students.StudentName.Length; i++)
                {
                    if (forbidden_symbols.IndexOf(students.StudentName[i])!=-1)
                    {
                        return RedirectToAction(nameof(Index), "Students", new { id = id });
                    }
                    if (students.StudentName[0] == ' '|| students.StudentName[1] == ' '|| students.StudentName[students.StudentName.Length-1]==' '|| students.StudentName[students.StudentName.Length - 1]==' ')
                    {
                        return RedirectToAction(nameof(Index), "Students", new { id= id });
                    }
                    
                }
                int[] whitespaces = new int[students.StudentName.Length];
                int white_space_counter = 0;
                //Перевірка на символ пробілу, який розділяє ім'я та прізвище
                for (int i = 2; i < students.StudentName.Length-2; i++)
                {
                    if (students.StudentName[i]==' ')
                    {
                        whitespaces[white_space_counter] = i;
                        white_space_counter++;
                    }
                    
                }
                if (white_space_counter==0)
                {
                    return RedirectToAction(nameof(Index), "Students", new { id = id });
                }
                //Перевірка на валідність дати, відсутність двох однакових імен, та валідність курсу
                if (StudentsExists(students.StudentName.ToUpper())||students.StudentBirthDate>_max_student_birthdate|| students.StudentBirthDate < _min_student_birthdate|| students.StudentCourseNum>maxcourse || students.StudentCourseNum<=0 )
                {
                    return RedirectToAction(nameof(Index), "Students", new { id = id });
                }
                /*
                char[] prev = students.StudentName.ToLower().ToCharArray();

                for (int i = 0; i < white_space_counter; i++)
                {
                    prev[whitespaces[i]] = Convert.ToChar(students.StudentName[whitespaces[i]].ToString().ToUpper());
                }*/
                students.StudentName = students.StudentName.ToUpper();
                
                _context.Add(students);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index),"Students", new { id = id });
            }
            ViewData["StudentCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName", students.StudentCountryId);
            ViewData["StudentGroupId"] = new SelectList(_context.Groups, "GroupId", "GroupName", students.StudentGroupId);
            return View(students);
        }

        // GET: Students/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var students = await _context.Students.FindAsync(id);
            if (students == null)
            {
                return NotFound();
            }
            ViewData["StudentCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName", students.StudentCountryId);
            ViewData["StudentGroupId"] = new SelectList(_context.Groups, "GroupId", "GroupName", students.StudentGroupId);
            return View(students);
        }

        // POST: Students/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StudentName,StudentId,StudentGroupId,StudentCountryId,StudentCourseNum,StudentBirthDate")] Students students)
        {
            if (id != students.StudentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(students);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentsExists(students.StudentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index","Students",students.StudentGroupId);
            }
            ViewData["StudentCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName", students.StudentCountryId);
            ViewData["StudentGroupId"] = new SelectList(_context.Groups, "GroupId", "GroupName", students.StudentGroupId);
            return View(students);
        }

        // GET: Students/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var students = await _context.Students
                .Include(s => s.StudentCountry)
                .Include(s => s.StudentGroup)
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (students == null)
            {
                return NotFound();
            }

            return View(students);
        }

        // POST: Students/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var students = await _context.Students.FindAsync(id);
            _context.Students.Remove(students);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentsExists(int id)
        {
            return _context.Students.Any(e => e.StudentId == id);
        }
        private bool StudentsExists(string Name)
        {
            return _context.Students.Any(e => e.StudentName == Name);
        }
    }
}
