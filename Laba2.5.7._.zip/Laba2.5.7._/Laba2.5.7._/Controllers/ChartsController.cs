﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Laba2._5._7._.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChartsController : ControllerBase
    {
        private readonly DbUniversityContext _context;

        public ChartsController(DbUniversityContext _contextt)
        {
            this._context = _contextt;
        }
        [HttpGet("JsonData")]
        public JsonResult JsonData()
        {
            var countries = _context.Countries.Include(cv => cv.Universities_Collection).ToList();

            List<object> CountryUniversity = new List<object>();

            CountryUniversity.Add(new[] { "Країна", "Кількість університетів" });
            foreach (var c in countries)
            {
                CountryUniversity.Add(new object[]{ c.CountryName, c.Universities_Collection.Count() });
            }
            return new JsonResult(CountryUniversity);
        }
    }
}