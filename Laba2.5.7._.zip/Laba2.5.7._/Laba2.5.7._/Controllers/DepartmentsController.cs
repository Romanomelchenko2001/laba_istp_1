﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._;
using Microsoft.AspNetCore.Authorization;

namespace Laba2._5._7._.Controllers
{
    [Authorize(Roles = "admin, user")]
    public class DepartmentsController : Controller
    {
        private readonly DbUniversityContext _context;
        private string forbidden_symbols = "1234567890!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        public DepartmentsController(DbUniversityContext context)
        {
            _context = context;
        }

        // GET: Departments
        public async Task<IActionResult> Index(int ? id)
        {
            if (id==null)
            {
                return RedirectToAction("Index", "Countries");
            }
            ViewBag.FacultyId = id;
            ViewBag.FacultyName = _context.Faculties.Where(c => c.FacultyId == id).FirstOrDefault().FacultyName;
            var DepartmentsByFaculties = _context.Departments.Where(cr => cr.DepartmentFacultyId == id).Include(c=>c.DepartmentFaculty);
            return View(await DepartmentsByFaculties.ToListAsync());
        }

        // GET: Departments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departments = await _context.Departments
                .Include(d => d.DepartmentFaculty)
                .FirstOrDefaultAsync(m => m.DepartmentId == id);
            if (departments == null)
            {
                return NotFound();
            }

            return RedirectToAction("Index", "Groups", new { id = id });
        }

        // GET: Departments/Create
        public IActionResult Create(int?id)
        {
            ViewBag.FacultyId = id;
            ViewBag.FacultyName = _context.Faculties.Where(it => it.FacultyId == id).FirstOrDefault().FacultyName;
          
            return View();
        }

        // POST: Departments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int id,[Bind("DepartmentName,DepartmentId,DepartmentFacultyId")] Departments departments)
        {
            departments.DepartmentFacultyId = id;
            
            if (ModelState.IsValid)
            {
                for (int i = 0; i < departments.DepartmentName.Length; i++)
                {
                    if (forbidden_symbols.IndexOf(departments.DepartmentName[i]) != -1|| departments.DepartmentName.Length>10)
                    {
                        return RedirectToAction(nameof(Index), "Departments", new { id = id });
                    }
                    if (departments.DepartmentName[0] == ' ' || departments.DepartmentName[1] == ' ' || departments.DepartmentName[departments.DepartmentName.Length - 1] == ' ' || departments.DepartmentName[departments.DepartmentName.Length - 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Departments", new { id = id });
                    }

                }
                for (int i = 1; i < departments.DepartmentName.Length-1; i++)
                {
                    if (departments.DepartmentName[i-1]==' '&&departments.DepartmentName[i]!=' '&&departments.DepartmentName[i+1]==' ')
                    {
                        return RedirectToAction(nameof(Index), "Departments", new { id = id });
                    }
                }
                departments.DepartmentName = departments.DepartmentName.ToUpper();
                departments.DepartmentFaculty = _context.Faculties.Where(z => z.FacultyId == departments.DepartmentFacultyId).FirstOrDefault();
                
                if (DepartmentsExists(departments.DepartmentName))
                {
                        return RedirectToAction(nameof(Index), "Departments", new { id = id });
                }
                departments.DepartmentFaculty.Departments.Add(departments);
                _context.Add(departments);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index","Departments",new { id = id});
            }
            //ViewData["DepartmentFacultyId"] = new SelectList(_context.Faculties, "FacultyId", "FacultyId", departments.DepartmentFacultyId);
            //return View(departments);
            return RedirectToAction("Index","Countries");
        }

        // GET: Departments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departments = await _context.Departments.FindAsync(id);
            if (departments == null)
            {
                return NotFound();
            }
            ViewData["DepartmentFacultyId"] = new SelectList(_context.Faculties, "FacultyId", "FacultyId", departments.DepartmentFacultyId);
            return View(departments);
        }

        // POST: Departments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DepartmentName,DepartmentId,DepartmentFacultyId")] Departments departments)
        {
            if (id != departments.DepartmentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(departments);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DepartmentsExists(departments.DepartmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index),"Departments",new { id = departments.DepartmentFacultyId });
            }
            ViewData["DepartmentFacultyId"] = new SelectList(_context.Faculties, "FacultyId", "FacultyId", departments.DepartmentFacultyId);
            return View(departments);
        }

        // GET: Departments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departments = await _context.Departments
                .Include(d => d.DepartmentFaculty)
                .FirstOrDefaultAsync(m => m.DepartmentId == id);
            if (departments == null)
            {
                return NotFound();
            }

            return View(departments);
        }

        // POST: Departments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var departments = await _context.Departments.FindAsync(id);
            _context.Departments.Remove(departments);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DepartmentsExists(int id)
        {
            return _context.Departments.Any(e => e.DepartmentId == id);
        }
        private bool DepartmentsExists(string name)
        {
            return _context.Departments.Any(e => e.DepartmentName == name);
        }
    }
}
