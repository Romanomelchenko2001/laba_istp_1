﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._;
using Microsoft.AspNetCore.Authorization;

namespace Laba2._5._7._.Controllers
{
    [Authorize(Roles="admin, user")]
    public class FacultiesController : Controller
    {
        private readonly DbUniversityContext _context;
        private string forbidden_symbols = "1234567890!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        public FacultiesController(DbUniversityContext context)
        {
            _context = context;
        }

        // GET: Faculties
        public async Task<IActionResult> Index(int? id)
        {
            if (id==null)
            {
                return RedirectToAction("Index", "Countries");
            }
            ViewBag.UniviId = id;
            ViewBag.UnivName = _context.Universities.Where(v => v.UniversityId == id).FirstOrDefault().UniversityName;
            //Microsoft.EntityFrameworkCore.Query.IIncludableQueryable<Universities, Countries> UniversitiesByCounry;

            var FacultiesByUniversity = _context.Faculties.Where(b => (b.FacultyUniversity.UniversityId == id)).Include(b => b.FacultyUniversity);
            return View(await FacultiesByUniversity.ToListAsync());
        }

        // GET: Faculties/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var faculties = await _context.Faculties.Where(ir => ir.FacultyId == id).FirstOrDefaultAsync();
            if (faculties == null)
            {
                return NotFound();
            }

            return RedirectToAction("Index", "Departments", new { id = id });
        }

        // GET: Faculties/Create
        public IActionResult Create(int? UniversityId)
        {
            ViewBag.UniversityId = UniversityId;
            ViewBag.UniversityName = _context.Universities.Where(c => c.UniversityId == UniversityId).FirstOrDefault().UniversityName;
           // var Faculty = new Faculties { FacultyUniversityId = Convert.ToInt32(UniversityId), FacultyUniversity = _context.Universities.Where(c => c.UniversityId == UniversityId).FirstOrDefault() };
            //ViewData["UniversityCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName");
            return View();
        }

        // POST: Faculties/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int UniversityId,[Bind("FacultyId,FacultyUniversityId,FacultyName")] Faculties faculties)
        {
            faculties.FacultyUniversityId = UniversityId;
            if (ModelState.IsValid)
            {
                for (int i = 0; i < faculties.FacultyName.Length; i++)
                {
                    if (forbidden_symbols.IndexOf(faculties.FacultyName[i]) != -1)
                    {
                        return RedirectToAction(nameof(Index), "Faculties", new { id = UniversityId });
                    }
                    if (faculties.FacultyName[0] == ' ' || faculties.FacultyName[1] == ' ' || faculties.FacultyName[faculties.FacultyName.Length - 1] == ' ' || faculties.FacultyName[faculties.FacultyName.Length - 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Faculties", new { id = UniversityId });
                    }

                }
                for (int i = 1; i < faculties.FacultyName.Length - 1; i++)
                {
                    if (faculties.FacultyName[i - 1] == ' ' && faculties.FacultyName[i] != ' ' && faculties.FacultyName[i + 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Faculties", new { id = UniversityId });
                    }
                }
                faculties.FacultyName = faculties.FacultyName.ToUpper();
                if (FacultiesExists(faculties.FacultyName))
                {
                    return RedirectToAction("Index","Faculties", new {id = UniversityId });
                }
                faculties.FacultyUniversity = _context.Universities.Where(cr => cr.UniversityId == UniversityId).FirstOrDefault();
                faculties.FacultyUniversity.Faculties.Add(faculties);
                _context.Add(faculties);
                _context.Universities.Where(cr => cr.UniversityId == faculties.FacultyUniversityId).FirstOrDefault().Faculties.Add(faculties);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index","Faculties", new { id = UniversityId });
            }
            return RedirectToAction("Index", "Countries");
            //ViewData["FacultyUniversityId"] = new SelectList(_context.Universities, "UniversityId", "UniversityName", faculties.FacultyUniversityId);
            //return View(faculties);
        }

        // GET: Faculties/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var faculties = await _context.Faculties.FindAsync(id);
            if (faculties == null)
            {
                return NotFound();
            }
            ViewData["FacultyUniversityId"] = new SelectList(_context.Universities, "UniversityId", "UniversityName", faculties.FacultyUniversityId);
            return View(faculties);
        }

        // POST: Faculties/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FacultyId,FacultyUniversityId,FacultyName")] Faculties faculties)
        {
            if (id != faculties.FacultyId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(faculties);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FacultiesExists(faculties.FacultyId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), "Faculties", new { id = faculties.FacultyUniversityId });
            }
            ViewData["FacultyUniversityId"] = new SelectList(_context.Universities, "UniversityId", "UniversityName", faculties.FacultyUniversityId);
            return View(faculties);
        }

        // GET: Faculties/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var faculties = await _context.Faculties
                .Include(f => f.FacultyUniversity)
                .FirstOrDefaultAsync(m => m.FacultyId == id);
            if (faculties == null)
            {
                return NotFound();
            }

            return View(faculties);
        }

        // POST: Faculties/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var faculties = await _context.Faculties.FindAsync(id);
            _context.Faculties.Remove(faculties);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FacultiesExists(int id)
        {
            return _context.Faculties.Any(e => e.FacultyId == id);
        }
        private bool FacultiesExists(string id)
        {
            return _context.Faculties.Any(e => e.FacultyName == id);
        }
    }
}
