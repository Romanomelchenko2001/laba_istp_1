﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._.Models;

namespace Laba2._5._7._.Controllers
{
    public class CountriesController : Controller
    {
        private readonly DbUniversityContext _context;
        private string forbidden_symbols = "1234567890!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        public CountriesController(DbUniversityContext context)
        {
            _context = context;
        }

        // GET: Countries
        public async Task<IActionResult> Index()
        {
            return View(await _context.Countries.ToListAsync());
        }

        // GET: Countries/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var countries = await _context.Countries.Where(m => m.CountryId == id)
                .FirstOrDefaultAsync();
            if (countries == null)
            {
                return NotFound();
            }

            return RedirectToAction("Index", "Universities", new { id = id, CountryName= countries.CountryName }) ;

            //return View(countries);
        }

        // GET: Countries/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Countries/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CountryId,CountryName")] Countries countries)
        {
            if (ModelState.IsValid)
            {
                for (int i = 0; i < countries.CountryName.Length; i++)
                {
                    if (forbidden_symbols.IndexOf(countries.CountryName[i]) != -1)
                    {
                        return RedirectToAction(nameof(Index), "Countries");
                    }
                    if (countries.CountryName[0] == ' ' || countries.CountryName[1] == ' ' || countries.CountryName[countries.CountryName.Length - 1] == ' ' || countries.CountryName[countries.CountryName.Length - 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Countries");
                    }

                }
                for (int i = 1; i < countries.CountryName.Length - 1; i++)
                {
                    if (countries.CountryName[i - 1] == ' ' && countries.CountryName[i] != ' ' && countries.CountryName[i + 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Countries");
                    }
                }
                countries.CountryName = countries.CountryName.ToUpper();
                if (CountriesExists(countries.CountryName))
                {
                    return RedirectToAction(nameof(Index));
                }
                _context.Add(countries);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(countries);
        }

        // GET: Countries/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var countries = await _context.Countries.FindAsync(id);
            if (countries == null)
            {
                return NotFound();
            }
            return View(countries);
        }

        // POST: Countries/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CountryId,CountryName")] Countries countries)
        {
            if (id != countries.CountryId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(countries);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CountriesExists(countries.CountryId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(countries);
        }

        // GET: Countries/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var countries = await _context.Countries
                .FirstOrDefaultAsync(m => m.CountryId == id);
           
            if (countries == null)
            {
                return NotFound();
            }

            return View(countries);
        }

        // POST: Countries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var countries = await _context.Countries.FindAsync(id);
            var universities = countries.Universities_Collection.ToArray();
            //_context.Universities.RemoveRange(universities);
            //_context.SaveChanges();
            //var UniversityIdList = _context.Universities.Where(r => r.UniversityCountryId == id).ToArray()
            _context.Countries.Remove(countries);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        private bool CountriesExists(int id)
        {
            return _context.Countries.Any(e => e.CountryId == id);
        }
        private bool CountriesExists(string id)
        {
            return _context.Countries.Any(e => e.CountryName == id);
        }
    }
}
