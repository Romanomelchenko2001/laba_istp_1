﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._.Models;
using Microsoft.AspNetCore.Authorization;
using ClosedXML.Excel;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace Laba2._5._7._.Controllers
{
    [Authorize(Roles = "admin,user")]
    public class CountriesController : Controller
    {
        private readonly DbUniversityContext _context;
        private string forbidden_symbols = "1234567890!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        public CountriesController(DbUniversityContext context)
        {
            _context = context;
        }

        // GET: Countries
        public async Task<IActionResult> Index()
        {
            return View(await _context.Countries.ToListAsync());
        }

        // GET: Countries/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var countries = await _context.Countries.Where(m => m.CountryId == id)
                .FirstOrDefaultAsync();
            if (countries == null)
            {
                return NotFound();
            }

            return RedirectToAction("Index", "Universities", new { id = id, CountryName= countries.CountryName }) ;

            //return View(countries);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Import(IFormFile fileExcel)
        {
            if (ModelState.IsValid)
            {
                if (fileExcel != null)
                {
                    using (var stream = new FileStream(fileExcel.FileName, FileMode.Create))
                    {
                        await fileExcel.CopyToAsync(stream);
                        using (XLWorkbook workBook = new XLWorkbook(stream, XLEventTracking.Disabled))
                        {

                            foreach (IXLWorksheet worksheet in workBook.Worksheets)
                            {
                                if (CountriesExists(worksheet.Name.ToUpper())||IsForbidden(worksheet.Name))
                                {
                                    continue;
                                }
                               
                                Countries newcat;
                                var c = (from cat in _context.Countries
                                         where cat.CountryName.Contains(worksheet.Name)
                                         select cat).ToList();
                                
                                if (c.Count > 0)
                                {
                                    newcat = c[0];
                                }
                                else
                                {
                                    newcat = new Countries();
                                    newcat.CountryName = worksheet.Name.ToUpper();
   
                                    _context.Countries.Add(newcat);
                                }
                        
                                foreach (IXLRow row in worksheet.RowsUsed().Skip(1))
                                {
                                    try
                                    {
                                        Universities book = new Universities();
                                        book.UniversityName = row.Cell(1).Value.ToString().ToUpper();
                                        book.UniversityCountryId = newcat.CountryId;
                                        book.UniversityCountry = newcat;
                                        if (UniversitiesExists(book.UniversityName)||IsForbidden(book.UniversityName))
                                        {
                                            continue;
                                        }
                                        _context.Universities.Add(book);
                                        var a = 0;//for calculating number of cycles passed
                                        var DeppCount = 0;
                                        Departments deppp = new Departments();
                                        for (int i = 2; i <= 5; i++)
                                        {
                                            DeppCount = 0;
                                            if (row.Cell(i).Value.ToString().Length > 0)
                                            {
                                                    Faculties author;

                                                    author = new Faculties();
                                                    author.FacultyName = row.Cell(i).Value.ToString().ToUpper();
                                                    author.FacultyUniversity = book;
                                                if (FacultiesExists(author.FacultyName)||IsForbidden(author.FacultyName))
                                                {
                                                    continue;
                                                }
                                                book.Faculties.Add(author);
                                                    _context.Add(author);
 
                                                    for (int j = i+5+a; j <= i + 6 + a; j++)
                                                    {
                                                        if (row.Cell(j).Value.ToString().Length > 0)
                                                        {
                                                            Departments depp;

                                                            depp = new Departments();
                                                            depp.DepartmentName = row.Cell(j).Value.ToString().ToUpper();
                                                            depp.DepartmentFaculty = author;
                                                            if (DepartmentExists(depp.DepartmentName) || IsForbidden(depp.DepartmentName))
                                                            {
                                                                continue;
                                                            }
                                                        author.Departments.Add(depp);
                                                            _context.Add(depp);
                                                        deppp = depp;
                                                        DeppCount++;
                                                        }
                                                    }
                                                    a++;
                                                if (DeppCount==1)
                                                {
                                                    _context.Departments.Remove(deppp);
                                                    _context.Faculties.Remove(author);

                                                }
                                            }
                                                
                                        }
                                        
                                    }
                                    catch (Exception e)
                                    {
                                        return RedirectToAction(nameof(Index));
                                    }
                                }
                            }
                        }
                    }
                }

                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        public ActionResult Export()
        {
            using (XLWorkbook workbook = new XLWorkbook(XLEventTracking.Disabled))
            {
                var categories = _context.Countries.Include("Universities_Collection").ToList();
               
                foreach (var c in categories)
                {
                    var worksheet = workbook.Worksheets.Add(c.CountryName);

                    worksheet.Cell("A1").Value = "Назва університету";
                    worksheet.Cell("B1").Value = "факультет 1";
                    worksheet.Cell("C1").Value = "факультет 2";
                    worksheet.Cell("D1").Value = "факультет 3";
                    worksheet.Cell("E1").Value = "факультет 4";
                    worksheet.Cell("F1").Value = "країна";
                    worksheet.Cell("G1").Value = "каф1 фак1";
                    worksheet.Cell("H1").Value = "каф2 фак1";
                    worksheet.Cell("I1").Value = "каф1 фак2";
                    worksheet.Cell("J1").Value = "каф2 фак2";
                    worksheet.Cell("K1").Value = "каф1 фак3";
                    worksheet.Cell("L1").Value = "каф2 фак3";
                    worksheet.Cell("M1").Value = "каф1 фак4";
                    worksheet.Cell("N1").Value = "каф2 фак4";
                    worksheet.Row(1).Style.Font.Bold = true;
                    var books = c.Universities_Collection.ToList();

                    var count = 0;
                    for (int i = 0; i < books.Count; i++)
                    {
                        worksheet.Cell(i + 2, 1).Value = books[i].UniversityName;

                        var ab = _context.Faculties.Where(c => c.FacultyUniversityId == books[i].UniversityId).ToList();
                        
                        int j = 0;
                        foreach (var a in ab)
                        {
                            var ar = _context.Departments.Where(c => c.DepartmentFacultyId == a.FacultyId).ToList();
                            if (ar.Count > 1)
                            {
                                if (j < 5)
                            {
                                worksheet.Cell(i + 2, j + 2).Value = a.FacultyName;
                                j++;
                            }
                            
                                int t = 0;
                                foreach (var item in ar)
                                {
                                    if(t<=2)
                                    {
                                        worksheet.Cell(i + 2, j + t + 6).Value = item.DepartmentName;
                                        t++;
                                    }

                                }

                            }
                            count++;
                        }
                        worksheet.Cell(i + 2, 6).Value = worksheet.Name;

                    }
                }
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    stream.Flush();

                    return new FileContentResult(stream.ToArray(),
                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    {
                        FileDownloadName = $"ArchiveUnivers_{DateTime.UtcNow.ToShortDateString()}.xlsx"
                    };
                }
            }
        }

        // GET: Countries/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Countries/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CountryId,CountryName")] Countries countries)
        {
            if (ModelState.IsValid)
            {
                for (int i = 0; i < countries.CountryName.Length; i++)
                {
                    if (forbidden_symbols.IndexOf(countries.CountryName[i]) != -1)
                    {
                        return RedirectToAction(nameof(Index), "Countries");
                    }
                    if (countries.CountryName[0] == ' ' || countries.CountryName[1] == ' ' || countries.CountryName[countries.CountryName.Length - 1] == ' ' || countries.CountryName[countries.CountryName.Length - 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Countries");
                    }

                }
                for (int i = 1; i < countries.CountryName.Length - 1; i++)
                {
                    if (countries.CountryName[i - 1] == ' ' && countries.CountryName[i] != ' ' && countries.CountryName[i + 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Countries");
                    }
                }
                countries.CountryName = countries.CountryName.ToUpper();
                if (CountriesExists(countries.CountryName))
                {
                    return RedirectToAction(nameof(Index));
                }
                _context.Add(countries);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(countries);
        }

        // GET: Countries/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var countries = await _context.Countries.FindAsync(id);
            if (countries == null)
            {
                return NotFound();
            }
            return View(countries);
        }

        // POST: Countries/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CountryId,CountryName")] Countries countries)
        {
            if (id != countries.CountryId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(countries);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CountriesExists(countries.CountryId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(countries);
        }

        // GET: Countries/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var countries = await _context.Countries
                .FirstOrDefaultAsync(m => m.CountryId == id);
           
            if (countries == null)
            {
                return NotFound();
            }

            return View(countries);
        }

        // POST: Countries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var countries = await _context.Countries.FindAsync(id);
            var universities = countries.Universities_Collection.ToArray();
            //_context.Universities.RemoveRange(universities);
            //_context.SaveChanges();
            //var UniversityIdList = _context.Universities.Where(r => r.UniversityCountryId == id).ToArray()
            _context.Countries.Remove(countries);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        private bool DepartmentExists(string id)
        {
            return _context.Departments.Any(e => e.DepartmentName == id);
        }
        private bool CountriesExists(int id)
        {
            return _context.Countries.Any(e => e.CountryId == id);
        }
        private bool CountriesExists(string id)
        {
            return _context.Countries.Any(e => e.CountryName == id);
        }
        private bool UniversitiesExists(string id)
        {
            return _context.Universities.Any(e => e.UniversityName == id);
        }
        private bool FacultiesExists(string id)
        {
            return _context.Faculties.Any(e => e.FacultyName == id);
        }
        private bool IsForbidden(string id)
        {
            for (int i = 0; i < id.Length; i++)
            {
                if (forbidden_symbols.IndexOf(id[i])!=-1)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
