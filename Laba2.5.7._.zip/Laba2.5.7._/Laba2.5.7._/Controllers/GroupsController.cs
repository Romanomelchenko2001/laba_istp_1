﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authorization;

namespace Laba2._5._7._.Controllers
{
    [Authorize(Roles ="admin, user")]
    public class GroupsController : Controller
    {
        private readonly DbUniversityContext _context;
        //private string forbidden_symbols = "!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        private string pat = @"^([a-z]{1}-[0-9]{1}[0-9]{1})|([a-z]{2}-[0-9]{1}[0-9]{1})$";
        public GroupsController(DbUniversityContext context)
        {
            _context = context;
        }

        // GET: Groups
        public async Task<IActionResult> Index(int?id)
        {
            if (id == null)
            {
                return RedirectToAction("Index", "Countries");
            }
            ViewBag.DepartmentsId = Convert.ToInt32(id);
            ViewBag.DepartmentsName = _context.Departments.Where(c => c.DepartmentId == Convert.ToInt32(id)).FirstOrDefault().DepartmentName;
           
            var GroupsByDepartments = _context.Groups.Where(cr => cr.GroupDepartmentId == id).Include(c => c.GroupDepartment);
            return View(await GroupsByDepartments.ToListAsync());
        }

        // GET: Groups/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var groups = await _context.Groups
                .Include(g => g.GroupDepartment)
                .FirstOrDefaultAsync(m => m.GroupId == id);
            if (groups == null)
            {
                return NotFound();
            }

            return RedirectToAction(nameof(Index), "Students", new { id = groups.GroupId });
        }

        // GET: Groups/Create
        public IActionResult Create(int ?id, int? CountryId)
        {
            ViewBag.DepartmentId = id;
            ViewBag.DepartmentName = _context.Departments.Where(cr => cr.DepartmentId == id).FirstOrDefault().DepartmentName;
            //ViewData["GroupDepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName");
            return View();
        }

        // POST: Groups/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int id,[Bind("GroupId,GroupName,GroupDepartmentId")] Groups groups)
        {
            //Перевірка на правильність назви групи
            if (Regex.IsMatch(groups.GroupName.ToLower(),pat))
            {
                Regex regex = new Regex(pat);
                Match match = regex.Match(groups.GroupName.ToLower());
                groups.GroupName = match.Value;
            }
            else
            {
                return RedirectToAction(nameof(Index), "Groups", new { id = id });
            }
            groups.GroupName = groups.GroupName.ToUpper();
            //перевірка на існування групи з такою назвою
            if (GroupsExists(groups.GroupName))
            {
                return RedirectToAction(nameof(Index), "Groups", new { id = id });
            }

            groups.GroupDepartmentId = id;
            if (ModelState.IsValid)
            {
                _context.Add(groups);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index),"Groups", new { id = id });
            }
            //ViewData["GroupDepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName", groups.GroupDepartmentId);
            return RedirectToAction("Index", "Countries");
        }

        // GET: Groups/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var groups = await _context.Groups.FindAsync(id);
            if (groups == null)
            {
                return NotFound();
            }
            ViewData["GroupDepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName", groups.GroupDepartmentId);
            return View(groups);
        }

        // POST: Groups/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("GroupId,GroupName,GroupDepartmentId")] Groups groups)
        {
            if (id != groups.GroupId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(groups);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GroupsExists(groups.GroupId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), "Groups", new { id = groups.GroupDepartmentId});
            }
            ViewData["GroupDepartmentId"] = new SelectList(_context.Departments, "DepartmentId", "DepartmentName", groups.GroupDepartmentId);
            return View(groups);
        }

        // GET: Groups/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var groups = await _context.Groups
                .Include(g => g.GroupDepartment)
                .FirstOrDefaultAsync(m => m.GroupId == id);
            if (groups == null)
            {
                return NotFound();
            }

            return View(groups);
        }

        // POST: Groups/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var groups = await _context.Groups.FindAsync(id);
            _context.Groups.Remove(groups);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GroupsExists(int id)
        {
            return _context.Groups.Any(e => e.GroupId == id);
        }
        private bool GroupsExists(string name)
        {
            return _context.Groups.Any(e => e.GroupName == name);
        }
    }
}
