﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._
{
    public partial class Faculties
    {
        public Faculties()
        {
            Departments = new HashSet<Departments>();
        }

        
        
        public int FacultyId { get; set; }

        [Display(Name = "Університет")]
        public int FacultyUniversityId { get; set; }
        [Required (ErrorMessage ="Поле не може бути порожнім")]
        [Display (Name="Назва факультету")]
        public string FacultyName { get; set; }
        [Display(Name = "Університет")]
        public virtual Universities FacultyUniversity { get; set; }
        public virtual ICollection<Departments> Departments { get; set; }
    }
}
