﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Identity;

namespace Laba2._5._7._.Models
{
    public class USER:IdentityUser
    {
        public int BirthYear { get; set; }
    }
}
