﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._
{
    public partial class Universities
    {
        public Universities()
        {
            Faculties = new HashSet<Faculties>();
        }
        [Required (ErrorMessage = "Don't leave this field empty, try again")]
        [Display(Name = "Назва університету")]
        public string UniversityName { get; set; }
        public int UniversityId { get; set; }
        [Display(Name = "Назва країни")]
        public int UniversityCountryId { get; set; }
        [Display(Name = "Країна університету")]
        public virtual Countries UniversityCountry { get; set; }
        public virtual ICollection<Faculties> Faculties { get; set; }
    }
}
