﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Laba2._5._7._.Models
{
    public class IdentityContext:IdentityDbContext<USER>
    {
        public IdentityContext(DbContextOptions<IdentityContext> options):base(options)
        {
            Database.EnsureCreated();
        }
    }
}
