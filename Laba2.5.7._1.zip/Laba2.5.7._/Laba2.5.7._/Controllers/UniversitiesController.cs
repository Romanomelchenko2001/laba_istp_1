﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Laba2._5._7._.Models;
using Microsoft.AspNetCore.Authorization;

namespace Laba2._5._7._.Controllers
{
    [Authorize(Roles = "admin,user")]

    public class UniversitiesController : Controller
    {
        private readonly DbUniversityContext _context;
        private string forbidden_symbols = "1234567890!@#$%^&*()_+-|}{\";'<>?/.,№₴";
        public UniversitiesController(DbUniversityContext context)
        {
            _context = context;
        }

        /*
        public async Task<IActionResult> Index()
        {
            return View(_context.Universities.ToList());
        }
        */
        // GET: Universities
        public async Task<IActionResult> Index(int?id)
        {
            if (id == null)
            {
                return RedirectToAction("Index", "Countries");
            }
            ViewBag.CountryId = id;
            ViewBag.CountryNName = _context.Countries.Where(v=>v.CountryId==id).FirstOrDefault().CountryName;
            //Microsoft.EntityFrameworkCore.Query.IIncludableQueryable<Universities, Countries> UniversitiesByCounry;

            var UniversitiesByCountry1 = _context.Universities.Where(b => (b.UniversityCountry.CountryId == id)).Include(b=>b.UniversityCountry);
            return View(await UniversitiesByCountry1.ToListAsync());
        }

        // GET: Universities/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var universities = await _context.Universities.Where(m => m.UniversityId == id)
                .FirstOrDefaultAsync();
            if (universities == null)
            {
                return NotFound();
            }

            return RedirectToAction("Index", "Faculties", new { id = universities.UniversityId });
        }

        // GET: Universities/Create
        public IActionResult Create(int? CountryId)
        {
            ViewBag.CountryId = CountryId;
            ViewBag.CountryName = _context.Countries.Where(c => c.CountryId == CountryId).FirstOrDefault().CountryName;
            //var University = new Universities { UniversityCountryId = Convert.ToInt32(CountryId), UniversityCountry = _context.Countries.Where(c => c.CountryId == CountryId).FirstOrDefault()};
            //ViewData["UniversityCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName");
            return View();
        }
        
        // POST: Universities/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int CountryId,[Bind("UniversityName,UniversityId,UniversityCountryId")] Universities universities)
        {
           universities.UniversityCountryId = CountryId;
            if (ModelState.IsValid)
            {
                for (int i = 0; i < universities.UniversityName.Length; i++)
                {
                    if (forbidden_symbols.IndexOf(universities.UniversityName[i]) != -1)
                    {
                        return RedirectToAction(nameof(Index), "Universities", new { id = CountryId });
                    }
                    if (universities.UniversityName[0] == ' ' || universities.UniversityName[1] == ' ' || universities.UniversityName[universities.UniversityName.Length - 1] == ' ' || universities.UniversityName[universities.UniversityName.Length - 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index), "Universities", new { id = CountryId });
                    }

                }
                for (int i = 1; i < universities.UniversityName.Length - 1; i++)
                {
                    if (universities.UniversityName[i - 1] == ' ' && universities.UniversityName[i] != ' ' && universities.UniversityName[i + 1] == ' ')
                    {
                        return RedirectToAction(nameof(Index),"Universities", new { id = CountryId });
                    }
                }
                universities.UniversityName = universities.UniversityName.ToUpper();
                if (UniversitiesExists(universities.UniversityName))
                {
                    return RedirectToAction(nameof(Index), "Universities", new { id = CountryId });
                }
                universities.UniversityCountry = _context.Countries.Where(cr => cr.CountryId == universities.UniversityCountryId).FirstOrDefault();
                _context.Add(universities);
                _context.Countries.Where(cr => cr.CountryId == universities.UniversityCountryId).FirstOrDefault().Universities_Collection.Add(universities);
                _context.SaveChanges();
                
                if (universities.UniversityCountry==null)
                {
                    int a = 1;
                    int b = 2;
                    int r = a + b;

                }
                if(universities.UniversityCountry.Universities_Collection.ToArray() == null)
                {
                    int a = 1;
                    int b = 2;
                    int r = a - b;
                }
                universities.UniversityCountry = _context.Countries.Where(cr => cr.CountryId == universities.UniversityCountryId).FirstOrDefault();
                return RedirectToAction(nameof(Index), "Universities", new { id = CountryId });
                //return RedirectToAction(nameof(Index));
                //return RedirectToAction("Index", "Countries");//, CountryId);
            }
            //ViewData["UniversityCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName", universities.UniversityCountryId);
            // return View(universities);
            return RedirectToAction("Index", "Countries");
        }
        

        // GET: Universities/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var universities = await _context.Universities.FindAsync(id);
            if (universities == null)
            {
                return NotFound();
            }
            ViewData["UniversityCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName", universities.UniversityCountryId);
            return View(universities);
        }

        // POST: Universities/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UniversityName,UniversityId,UniversityCountryId")] Universities universities)
        {
            if (id != universities.UniversityId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(universities);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UniversitiesExists(universities.UniversityId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index","Universities", new { id = universities.UniversityCountryId });
            }
            ViewData["UniversityCountryId"] = new SelectList(_context.Countries, "CountryId", "CountryName", universities.UniversityCountryId);
            return View(universities);
        }

        // GET: Universities/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            ViewBag.UnivId = id;
            //var a = _context.Universities.ToArray();
            //var universities = a[0];
            ViewBag.UnivName = _context.Universities.Where(r => r.UniversityId == id).FirstOrDefault().UniversityName;
            /*for (int i = 0; i < a.Length; i++)
           {
                if (a[i].UniversityId==id)
                {
                    universities = a[i];
                    break;
                }
            }*/
            var universities = await _context.Universities
               .FirstOrDefaultAsync(m => m.UniversityId == id);

            if (universities == null)
            {
                return NotFound();
            }

            return View(universities);
        }

        // POST: Universities/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            //var Univ = _context.Universities.Where(t => t.UniversityId == id).FirstOrDefault().UniversityName;
            var universities = await _context.Universities.FindAsync(id);
            _context.Universities.Remove(universities);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Countries");
        }

        private bool UniversitiesExists(int id)
        {
            return _context.Universities.Any(e => e.UniversityId == id);
        }
        private bool UniversitiesExists(string name)
        {
            return _context.Universities.Any(e => e.UniversityName == name);
        }
    }
}
