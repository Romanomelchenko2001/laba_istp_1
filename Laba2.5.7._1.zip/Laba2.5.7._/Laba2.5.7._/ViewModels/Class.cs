﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Laba2._5._7._.ViewModels
{
    public class LoginViewModel
    {
        
        [Required]
        [Display(Name="Email")]

        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Пароль")]
        public string Password { get; set; }

        [Display(Name = "Запам'ятай")]
        public bool RememberMe { get; set; }

        public string ReturnUrl { get; set; }
    }
}
